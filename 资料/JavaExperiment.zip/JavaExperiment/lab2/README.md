# README
**To run:**
* use mariadb/mysql
    * login using root
    * create a database with name "java_lab2"
    * create a user named "java" with password set to "javajava", and grant all privileges on java_lab2 to it.
    * run `source sample_data.sql` under java_lab2
    * start mariadb/mysql service
* use jre8
    * run `java -jar out/hims.jar` to run the program (make sure to use java 8)

# NOTE
this program has no security.
